import { createFileRoute } from "@tanstack/react-router";

// The original site is kept as standalone HTML in public/ and shown full-screen here,
// so its look and behaviour stay exactly as they were.
export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "YATHARTH" },
      { name: "description", content: "Yatharth — animated cover page" },
      { property: "og:title", content: "YATHARTH" },
      { property: "og:description", content: "Yatharth — animated cover page" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      src="/yatharth.html"
      title="YATHARTH"
      allow="autoplay; fullscreen; clipboard-write"
      className="fixed inset-0 h-full w-full border-0 bg-background"
    />
  );
}
